package com.pro;

public class Calculator {
    public int add(String st){
        if(st.isEmpty()){
            return 0;
        }
        else {
            String del = ",|\\n";
            String a[] = st.split(del);
            int result= 0;
            for(String s : a){
                int num =  Integer.parseInt(s);
                if(num<0){
                    throw new IllegalArgumentException("negative numbers not allowed " + num);
                }
                result = result + num;
            }
            return result;
        }
    }
}
