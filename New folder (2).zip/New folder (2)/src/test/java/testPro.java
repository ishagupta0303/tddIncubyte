import com.pro.Calculator;
import org.junit.Test;
import static org.junit.Assert.*;

public class testPro {
    @Test
    public void doNothing(){

    }

    @Test
    public void testEmptyString() {
        Calculator c = new Calculator();
        assertEquals(0, c.add(""));
    }

    @Test
    public void testSingleString(){
        Calculator c = new Calculator();
        assertEquals(1, c.add("1"));
    }

    @Test
    public void testTwoString(){
        Calculator c = new Calculator();
        assertEquals(3, c.add("1,2"));
}

    @Test
    public void testStringWithNewLine(){
        Calculator c = new Calculator();
        assertEquals(3, c.add("1\n2"));
    }

    @Test
    public void testThree(){
        Calculator c = new Calculator();
        assertEquals(6, c.add("1,2\n3"));
    }

    @Test
    public void testWithOtherDel(){
        Calculator c = new Calculator();
        assertEquals(3, c.add("//;\n1;2"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNegativeNumbers() {
        Calculator c = new Calculator();
        c.add("1,-2,3,-4");
    }

}
